import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import ShapesList from "./components/ShapesList"; 
import HelpPage from "./pages/HelpPage";
import HomePage from "./pages/HomePage";


const App = () => {
  return (
    <Router>

        <div className="app-container">
          <Routes>
            {/* <Route path="/" element={<ShapeDrawingApp />} /> */}
            <Route path="/game" element={<ShapesList />} />
            <Route path="/help" element={<HelpPage />} /> 
            <Route path="/" element={<HomePage />} />
          </Routes>
        </div>
 
    </Router>
  );
};

export default App;